<html>
    <head>
        <body>
            @yield('judul_menu')
            @yield('isi_menu')
        </body>
    </head>
</html>





